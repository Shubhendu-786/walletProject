package UpdationEquipments;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@CucumberOptions(features="pretty")
@RunWith(Cucumber.class)
public class TestCukes {

}
