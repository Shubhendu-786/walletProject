package UpdationEquipments;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	@Given("^requirements$")
	public void requirements() throws Throwable {
	  
	}

	@Given("^locations$")
	public void locations1() throws Throwable {
	  
	}

	@Given("^users$")
	public void users1() throws Throwable {
	  
	}

	@When("^Valid Requirements$")
	public void valid_Requirements() throws Throwable {
	  
	}

	@When("^locations$")
	public void locations() throws Throwable {
	  
	}

	@When("^users$")
	public void users() throws Throwable {
	  
	}

	@Then("^I update the equipment records$")
	public void i_update_the_equipment_records() throws Throwable {
	  
	}

}
