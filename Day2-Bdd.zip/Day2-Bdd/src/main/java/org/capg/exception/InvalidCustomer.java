package org.capg.exception;

public class InvalidCustomer extends Exception{
 public InvalidCustomer(String message)
 {
	 super(message);
 }
}
