package org.capg.exception;

public class InvalidOpeningBalance extends Exception{
public InvalidOpeningBalance(String message)
{
	super(message);
}
}
