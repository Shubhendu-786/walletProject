package org.capg.service;

import org.capg.exception.InvalidCustomer;
import org.capg.exception.InvalidOpeningBalance;
import org.capg.model.Account;
import org.capg.model.Customer;

public interface IAccountService {

	public Account createAccount(Customer customer,double amount) throws InvalidCustomer,InvalidOpeningBalance;
	
}
