package org.capg.service;

import org.capg.exception.InvalidCustomer;
import org.capg.exception.InvalidOpeningBalance;
import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.util.AccountUtil;

public class AccountServiceImpl  implements IAccountService{

	@Override
	public Account createAccount(Customer customer, double amount) throws InvalidCustomer, InvalidOpeningBalance {
		if(customer!=null) {
			if(amount>=500) {
				Account account = new Account();
				account.setCustomer(customer);
				account.setOpeningBalance(amount);
				account.setAccountNo(AccountUtil.generateAccountNo());
				return account;
			}
			else
			{
				throw new InvalidOpeningBalance("sorry! Customer refers1 null.");
			}
			
			
		}
		
		else
		{
			throw new InvalidCustomer("sorry! Customer refers null.");
		}
	}

}

