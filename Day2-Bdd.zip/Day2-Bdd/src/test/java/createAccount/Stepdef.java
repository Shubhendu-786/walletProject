package createAccount;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.capg.exception.InvalidCustomer;
import org.capg.exception.InvalidOpeningBalance;
import org.capg.model.Account;
import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.service.AccountServiceImpl;
import org.capg.service.IAccountService;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	Customer customer;
	private double openingBalance;
	private IAccountService accountService;
	
	@Before
	public void setup() {
		customer=new Customer();
		openingBalance=500;
		accountService=new AccountServiceImpl();
	}
	
	@Given("^customer details$")
	public void customer_details() throws Throwable {
		 customer.setFirstName("Manu");
		  customer.setLastName("Nama");
		  Address address=new Address();
		  address.setDoorNo("12");
		  address.setCity("chennai");
		  customer.setAddress(address);
	}

	@When("^Valid Customer$")
	public void valid_Customer() throws Throwable {
	
		assertNotNull(customer);
	}

	@When("^valid opening balance$")
	public void valid_opening_balance() throws Throwable {
		assertTrue(openingBalance>=500);
	}

	@Then("^craete new Account$")
	public void craete_new_Account() throws Throwable {
		   Account account = accountService.createAccount(customer, openingBalance);
		   assertNotNull(account);
		   assertEquals(openingBalance, account.getOpeningBalance(),0.0);;
		   assertEquals(account.getAccountNo(), 1);
	}
	
	
	@Given("^Customer details$")
	public void customer_details1() throws Throwable {
	  customer=null;
	}

	@When("^Invalid Customer$")
	public void invalid_Customer() throws Throwable {
	 assertNull(customer);
	}

	@Then("^throw 'Invalid Customer' error message$")
	public void throw_Invalid_Customer_error_message() throws Throwable {
	try
	{
		accountService.createAccount(customer, 3000);
	}
	catch(InvalidCustomer e)
	{
		
	}
	}
	
	
	
	
	@Given("^Customer details and openingbalance$")
	public void customer_details_and_openingbalance() throws Throwable {
	   openingBalance=100;
	}

	@When("^Invalid opening balance$")
	public void invalid_opening_balance() throws Throwable {
	    assertTrue(openingBalance<=1000);
	}

	@Then("^throw 'insufficient Balance' error message$")
	public void throw_insufficient_Balance_error_message() throws Throwable {
	   try
	   {
		   accountService.createAccount(customer, openingBalance);
	   }
	   catch(InvalidOpeningBalance e)
	   {
		   
	   }
	}


	
	
}
