package com.capg.demo.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.demo.model.Attraction;
import com.capg.demo.service.PilotServiceInterface;



@RestController
@RequestMapping("/api/v3")
public class MyControl {

	@Autowired
	private PilotServiceInterface pilotDBService;
	
	/*Email e=new Email();
	@GetMapping("/pro")
	public void getAllCustomer(){
		System.out.println("I am in controller");
		System.out.println("I am in pilots");
		List<Customer> customers= pilotDBService.getAllCustomer();
		List<Inventory> inventory=pilotDBService.getAllInventory();
		//if(customers.isEmpty()||customers==null)
		
		int i;
		int j;
		//if(inventory.isEmpty()||inventory==null)
		for(i=0;i<customers.size()-1;i++)
		{for(j=0;j<inventory.size()-1;i++)
		{
			e.seteID(e.geteID()+1);
		e.setFrom_emailId("admin@gmail.com");
		e.setTo_emailId(customers.get(i).getEmail());
		e.setBody(inventory.get(j).getDescription());
		e.setSubject("promotion");
		e.setDate(new Date());
		
		pilotDBService.saveMail(e);
		}	
		}
		
    		//return null;
		//return new ResponseEntity<List<Email>>(,HttpStatus.OK);
	}*/
	/*
	@GetMapping("/")
	public ResponseEntity<List<UploadImage>> getAllImage()
	{
		List<UploadImage> images=pilotDBService.getAllImage();
		return new ResponseEntity<List<UploadImage>>(images,HttpStatus.OK);
	}*/
	
	@GetMapping("/maxId")
	public Integer getMaxId()
	{System.out.println("id : controller");
	  int i=pilotDBService.getMaxId();
	  System.out.println("i is"+i);
	  
	  
		return i;
	}
	
	@PostMapping("/put1")
	public void putImage(@RequestBody Attraction product)
	{System.out.println("Put : controller");
		pilotDBService.save(product);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Attraction>> getAllPilots(){
		System.out.println("getall : controller");
		//System.out.println("I am in pilots");
		List<Attraction> products= pilotDBService.getAllProducts();
		if(products.isEmpty()||products==null)
			return new ResponseEntity
				("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Attraction>>(products,HttpStatus.OK);
	}
	
	
}
